// Frontend API client for GeoAgent backend

import {
  AuthTokens,
  Device,
  LocationPoint,
  LocationHistory,
  LocationPermission,
  PermissionList,
  LoginRequest,
  RegisterRequest,
  CreateDeviceRequest,
  GrantPermissionRequest,
  LocationSubmitRequest,
  User,
} from "@/types";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface ApiClientConfig {
  baseURL: string;
  token?: string;
}

class ApiClient {
  private baseURL: string;
  private token: string | null = null;

  constructor(config: Partial<ApiClientConfig> = {}) {
    this.baseURL = config.baseURL || API_BASE;

    // Load token from localStorage if available
    if (typeof window !== "undefined") {
      this.token = localStorage.getItem("access_token");
    }
  }

  setToken(token: string) {
    this.token = token;
    if (typeof window !== "undefined") {
      localStorage.setItem("access_token", token);
    }
  }

  clearToken() {
    this.token = null;
    if (typeof window !== "undefined") {
      localStorage.removeItem("access_token");
      localStorage.removeItem("refresh_token");
    }
  }

  private getHeaders(includeAuth: boolean = true): Record<string, string> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (includeAuth && this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }

    return headers;
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || error.error || "API Error");
    }
    return response.json();
  }

  // ===== Authentication =====

  async register(data: RegisterRequest): Promise<User> {
    const response = await fetch(`${this.baseURL}/auth/register`, {
      method: "POST",
      headers: this.getHeaders(false),
      body: JSON.stringify(data),
    });
    return this.handleResponse(response);
  }

  async login(data: LoginRequest): Promise<AuthTokens> {
    const response = await fetch(`${this.baseURL}/auth/login`, {
      method: "POST",
      headers: this.getHeaders(false),
      body: JSON.stringify(data),
    });
    const tokens = await this.handleResponse<AuthTokens>(response);
    this.setToken(tokens.access_token);
    return tokens;
  }

  async refreshToken(refreshToken: string): Promise<AuthTokens> {
    const response = await fetch(`${this.baseURL}/auth/refresh`, {
      method: "POST",
      headers: this.getHeaders(false),
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    const tokens = await this.handleResponse<AuthTokens>(response);
    this.setToken(tokens.access_token);
    return tokens;
  }

  // ===== Devices =====

  async createDevice(data: CreateDeviceRequest): Promise<Device> {
    const response = await fetch(`${this.baseURL}/devices`, {
      method: "POST",
      headers: this.getHeaders(true),
      body: JSON.stringify(data),
    });
    return this.handleResponse(response);
  }

  async listDevices(): Promise<Device[]> {
    const response = await fetch(`${this.baseURL}/devices`, {
      method: "GET",
      headers: this.getHeaders(true),
    });
    return this.handleResponse(response);
  }

  async getDevice(deviceId: string): Promise<Device> {
    const response = await fetch(`${this.baseURL}/devices/${deviceId}`, {
      method: "GET",
      headers: this.getHeaders(true),
    });
    return this.handleResponse(response);
  }

  async updateDevice(
    deviceId: string,
    data: Partial<{ name: string; is_active: boolean }>
  ): Promise<Device> {
    const response = await fetch(`${this.baseURL}/devices/${deviceId}`, {
      method: "PATCH",
      headers: this.getHeaders(true),
      body: JSON.stringify(data),
    });
    return this.handleResponse(response);
  }

  async deleteDevice(deviceId: string): Promise<void> {
    const response = await fetch(`${this.baseURL}/devices/${deviceId}`, {
      method: "DELETE",
      headers: this.getHeaders(true),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || error.error || "Failed to delete device");
    }
  }

  // ===== Locations =====

  async submitLocation(
    deviceId: string,
    data: LocationSubmitRequest
  ): Promise<LocationPoint> {
    const response = await fetch(
      `${this.baseURL}/locations?device_id=${deviceId}`,
      {
        method: "POST",
        headers: this.getHeaders(true),
        body: JSON.stringify(data),
      }
    );
    return this.handleResponse(response);
  }

  async getCurrentLocation(deviceId: string): Promise<LocationPoint> {
    const response = await fetch(
      `${this.baseURL}/locations/current/${deviceId}`,
      {
        method: "GET",
        headers: this.getHeaders(true),
      }
    );
    return this.handleResponse(response);
  }

  async getLocationHistory(
    deviceId: string,
    startDate?: string,
    endDate?: string,
    limit: number = 1000
  ): Promise<LocationHistory> {
    const params = new URLSearchParams();
    if (startDate) params.append("start_date", startDate);
    if (endDate) params.append("end_date", endDate);
    params.append("limit", limit.toString());

    const response = await fetch(
      `${this.baseURL}/locations/history/${deviceId}?${params}`,
      {
        method: "GET",
        headers: this.getHeaders(true),
      }
    );
    return this.handleResponse(response);
  }

  // ===== Permissions =====

  async grantPermission(data: GrantPermissionRequest): Promise<LocationPermission> {
    const response = await fetch(`${this.baseURL}/permissions/location`, {
      method: "POST",
      headers: this.getHeaders(true),
      body: JSON.stringify(data),
    });
    return this.handleResponse(response);
  }

  async revokePermission(permissionId: string): Promise<void> {
    const response = await fetch(
      `${this.baseURL}/permissions/location/${permissionId}`,
      {
        method: "DELETE",
        headers: this.getHeaders(true),
      }
    );
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || error.error || "Failed to revoke permission");
    }
  }

  async listPermissions(): Promise<PermissionList> {
    const response = await fetch(`${this.baseURL}/permissions`, {
      method: "GET",
      headers: this.getHeaders(true),
    });
    return this.handleResponse(response);
  }
}

export const apiClient = new ApiClient();
