"use client";

import { FormEvent, useState } from "react";
import { Panel } from "@/components/ui/Panel";
import { Button } from "@/components/ui/Button";

export function AIPanel() {
  const [query, setQuery] = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
  }

  return (
    <Panel className="flex flex-col gap-3 p-4">
      <h2 className="text-xs font-medium uppercase tracking-wider text-text-secondary">
        AI Geo Analyst
      </h2>
      <form onSubmit={handleSubmit} className="flex gap-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask anything about the selected location or area…"
          className="flex-1 rounded-md border border-border bg-bg px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-secondary/60 focus:border-live/60"
        />
        <Button type="submit" variant="ghost" disabled={!query.trim()}>
          Ask
        </Button>
      </form>
      <p className="text-xs text-text-secondary">
        GeoAgent connects once the AI agent service is live in a later phase.
      </p>
    </Panel>
  );
}