import { Panel } from "@/components/ui/Panel";
import { StatusDot } from "@/components/ui/StatusDot";

const telemetryFields = [
  { label: "LAT", value: "—" },
  { label: "LNG", value: "—" },
  { label: "ACCURACY", value: "—" },
];

export function StatusPanel() {
  return (
    <Panel className="flex h-full flex-col gap-5 p-4">
      <div>
        <h2 className="text-xs font-medium uppercase tracking-wider text-text-secondary">
          Live Status
        </h2>
        <div className="mt-3 flex flex-col gap-2">
          <StatusDot label="GPS LOCK" tone="neutral" />
          <StatusDot label="SATELLITE LINK" tone="neutral" />
          <StatusDot label="LOCATION STREAM" tone="neutral" />
        </div>
      </div>

      <div className="border-t border-border pt-4">
        <h3 className="text-xs font-medium uppercase tracking-wider text-text-secondary">
          Position
        </h3>
        <dl className="mt-3 flex flex-col gap-2">
          {telemetryFields.map((field) => (
            <div key={field.label} className="flex items-center justify-between">
              <dt className="font-mono text-xs text-text-secondary">{field.label}</dt>
              <dd className="font-mono text-sm text-text-primary">{field.value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <p className="mt-auto text-xs leading-relaxed text-text-secondary">
        Select a device with active tracking to see live telemetry.
      </p>
    </Panel>
  );
}