"use client";

import { useRouter } from "next/navigation";
import { Logo } from "@/components/ui/Logo";
import { StatusDot } from "@/components/ui/StatusDot";
import { Button } from "@/components/ui/Button";
import { logout } from "@/lib/auth";

export function TopBar() {
  const router = useRouter();

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-panel px-6">
      <div className="flex items-center gap-6">
        <Logo />
        <span className="hidden font-mono text-xs uppercase tracking-wider text-text-secondary sm:inline">
          Satellite Intelligence Console
        </span>
      </div>

      <div className="flex items-center gap-5">
        <StatusDot label="SYSTEM ONLINE" tone="success" />
        <Button
          variant="ghost"
          onClick={() => {
            logout();
            router.push("/login");
          }}
        >
          Sign out
        </Button>
      </div>
    </header>
  );
}