import { Panel } from "@/components/ui/Panel";

const placeholderDevices = [
  { id: "1", name: "Device 01", active: true },
  { id: "2", name: "Device 02", active: false },
  { id: "3", name: "Device 03", active: false },
];

export function DeviceSidebar() {
  return (
    <Panel className="flex h-full flex-col p-4">
      <h2 className="text-xs font-medium uppercase tracking-wider text-text-secondary">
        Tracked Devices
      </h2>

      <ul className="mt-4 flex flex-1 flex-col gap-1">
        {placeholderDevices.map((device) => (
          <li key={device.id}>
            <button
              className="flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-sm text-text-primary transition-colors hover:bg-bg"
              type="button"
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  device.active ? "bg-success" : "bg-text-secondary/50"
                }`}
                aria-hidden="true"
              />
              {device.name}
            </button>
          </li>
        ))}
      </ul>

      <button
        type="button"
        className="mt-2 rounded-md border border-dashed border-border px-2.5 py-2 text-left text-sm text-text-secondary transition-colors hover:border-text-secondary hover:text-text-primary"
      >
        + Add device
      </button>
    </Panel>
  );
}