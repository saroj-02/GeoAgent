import { Panel } from "@/components/ui/Panel";

export function MapPlaceholder() {
  return (
    <Panel className="relative flex h-full min-h-[420px] items-center justify-center overflow-hidden">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(#7F8B99 1px, transparent 1px), linear-gradient(90deg, #7F8B99 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
        aria-hidden="true"
      />
      <div className="relative z-10 flex flex-col items-center gap-3 text-center">
        <span className="relative flex h-3 w-3">
          <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-live" />
          <span className="relative inline-flex h-3 w-3 rounded-full bg-live" />
        </span>
        <p className="font-mono text-xs uppercase tracking-wider text-text-secondary">
          Satellite map — connecting
        </p>
        <p className="max-w-xs text-sm text-text-secondary">
          Live map, location marker, and breadcrumb trail render here once a
          device begins reporting authorized location updates.
        </p>
      </div>
    </Panel>
  );
}