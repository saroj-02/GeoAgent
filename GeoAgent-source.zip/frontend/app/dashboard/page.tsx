import { TopBar } from "@/components/dashboard/TopBar";
import { DeviceSidebar } from "@/components/dashboard/DeviceSidebar";
import { MapPlaceholder } from "@/components/dashboard/MapPlaceholder";
import { StatusPanel } from "@/components/dashboard/StatusPanel";
import { TelemetryBar } from "@/components/dashboard/TelemetryBar";
import { AIPanel } from "@/components/dashboard/AIPanel";

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen flex-col bg-bg">
      <TopBar />

      <main className="flex flex-1 flex-col gap-4 p-4 lg:p-6">
        <div className="grid flex-1 grid-cols-1 gap-4 lg:grid-cols-[240px_1fr_280px]">
          <div className="order-2 lg:order-1">
            <DeviceSidebar />
          </div>
          <div className="order-1 min-h-[420px] lg:order-2">
            <MapPlaceholder />
          </div>
          <div className="order-3">
            <StatusPanel />
          </div>
        </div>

        <TelemetryBar />
        <AIPanel />
      </main>
    </div>
  );
}