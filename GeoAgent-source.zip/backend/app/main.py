import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.core.database import init_db, close_db
from app.api.routes import auth, users, device, location, permission, satellite, analysis, geofences, agent

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown."""
    logger.info(f"Starting {settings.APP_NAME} in {settings.ENV} mode")
    logger.info("Connecting to MongoDB Atlas...")
    await init_db()
    logger.info("MongoDB indexes created successfully")
    yield
    logger.info(f"Shutting down {settings.APP_NAME}")
    await close_db()


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    description="AI-Powered Satellite & Geospatial Intelligence Platform",
    version="1.0.0",
    lifespan=lifespan,
    debug=settings.DEBUG,
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"],  # Allow all for development; restrict in production
)


# Health check
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "environment": settings.ENV,
        "database": "MongoDB Atlas",
    }


# Include routers
app.include_router(auth.router, prefix="/api/v1", tags=["Authentication"])
app.include_router(users.router, prefix="/api/v1", tags=["Users"])
app.include_router(device.router, prefix="/api/v1", tags=["Devices"])
app.include_router(location.router, prefix="/api/v1", tags=["Locations"])
app.include_router(permission.router, prefix="/api/v1", tags=["Permissions"])
app.include_router(satellite.router, prefix="/api/v1", tags=["Satellite"])
app.include_router(analysis.router, prefix="/api/v1", tags=["Analysis"])
app.include_router(geofences.router, prefix="/api/v1", tags=["Geofences"])
app.include_router(agent.router, prefix="/api/v1", tags=["AI Agent"])


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )