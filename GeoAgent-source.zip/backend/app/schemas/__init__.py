"""
Pydantic schemas for API request/response validation.
"""

from datetime import datetime
from typing import Optional, List
from uuid import UUID
from pydantic import BaseModel, EmailStr, Field, validator


# ===== Auth Schemas =====

class UserRegisterRequest(BaseModel):
    """User registration request"""
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=100)
    password: str = Field(..., min_length=8, max_length=255)
    full_name: Optional[str] = Field(None, max_length=255)
    
    @validator('password')
    def validate_password(cls, v):
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


class UserLoginRequest(BaseModel):
    """User login request"""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Token response"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class RefreshTokenRequest(BaseModel):
    """Refresh token request"""
    refresh_token: str


# ===== User Schemas =====

class UserResponse(BaseModel):
    """User response (public data)"""
    id: UUID
    email: str
    username: str
    full_name: Optional[str]
    email_verified: bool
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


class UserDetailResponse(UserResponse):
    """User response with additional details"""
    phone: Optional[str]
    phone_verified: bool
    is_admin: bool
    location_history_enabled: bool
    location_retention_days: int
    last_login: Optional[datetime]
    updated_at: datetime


class UserUpdateRequest(BaseModel):
    """User update request"""
    full_name: Optional[str] = None
    phone: Optional[str] = None
    location_history_enabled: Optional[bool] = None
    location_retention_days: Optional[int] = Field(None, ge=1, le=365)


# ===== Device Schemas =====

class DeviceCreateRequest(BaseModel):
    """Create device request"""
    name: str = Field(..., min_length=1, max_length=255)
    device_type: str = Field(..., description="mobile, tablet, web, iot")
    unique_identifier: str = Field(..., description="IMEI, UUID, MAC address, etc.")


class DeviceResponse(BaseModel):
    """Device response"""
    id: UUID
    name: str
    device_type: str
    unique_identifier: str
    is_active: bool
    last_seen: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True


class DeviceUpdateRequest(BaseModel):
    """Update device request"""
    name: Optional[str] = None
    is_active: Optional[bool] = None


# ===== Location Schemas =====

class LocationPointCreateRequest(BaseModel):
    """Location update from device"""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    accuracy: Optional[float] = Field(None, ge=0)
    altitude: Optional[float] = None
    speed: Optional[float] = Field(None, ge=0)
    heading: Optional[float] = Field(None, ge=0, le=360)
    timestamp: datetime = Field(..., description="Device timestamp")
    source: str = Field(default="gps", description="gps, wifi, cellular, simulated")


class LocationPointResponse(BaseModel):
    """Location point response"""
    id: UUID
    device_id: UUID
    latitude: float
    longitude: float
    accuracy: Optional[float]
    altitude: Optional[float]
    speed: Optional[float]
    heading: Optional[float]
    timestamp: datetime
    created_at: datetime
    source: str
    is_valid: bool
    
    class Config:
        from_attributes = True


class LocationHistoryResponse(BaseModel):
    """Location history response"""
    device_id: UUID
    points: List[LocationPointResponse]
    count: int
    period_start: datetime
    period_end: datetime


# ===== Permission Schemas =====

class LocationPermissionCreateRequest(BaseModel):
    """Grant location permission request"""
    device_id: UUID
    granted_to_email: str = Field(..., description="Email of user to grant permission to")
    can_view_current: bool = True
    can_view_history: bool = False
    can_view_trail: bool = True
    permission_level: str = Field(default="viewer", description="owner, admin, viewer")
    expires_at: Optional[datetime] = None


class LocationPermissionResponse(BaseModel):
    """Location permission response"""
    id: UUID
    device_id: UUID
    granted_by_id: UUID
    granted_to_id: UUID
    can_view_current: bool
    can_view_history: bool
    can_view_trail: bool
    status: str
    permission_level: str
    expires_at: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True


class PermissionListResponse(BaseModel):
    """User permissions response"""
    granted_by_me: List[LocationPermissionResponse] = []
    granted_to_me: List[LocationPermissionResponse] = []


# ===== Geofence Schemas =====

class GeofenceCreateRequest(BaseModel):
    """Create geofence request"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    center_lat: float = Field(..., ge=-90, le=90)
    center_lng: float = Field(..., ge=-180, le=180)
    radius_meters: float = Field(..., gt=0)
    alert_on_enter: bool = True
    alert_on_exit: bool = True


class GeofenceResponse(BaseModel):
    """Geofence response"""
    id: UUID
    name: str
    description: Optional[str]
    center_lat: float
    center_lng: float
    radius_meters: float
    alert_on_enter: bool
    alert_on_exit: bool
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


# ===== System Schemas =====

class HealthResponse(BaseModel):
    """Health check response"""
    status: str = "healthy"
    environment: str
    version: str
    timestamp: datetime


class ErrorResponse(BaseModel):
    """Error response"""
    error: str
    detail: Optional[str] = None
    timestamp: datetime
