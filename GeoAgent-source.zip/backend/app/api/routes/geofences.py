"""
Geofence API routes.
"""

import logging
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.database import get_async_db
from app.core.security import SecurityService
from app.services.auth import AuthService
from app.models import User, Geofence
from app.schemas import GeofenceCreateRequest, GeofenceResponse

logger = logging.getLogger(__name__)
security = HTTPBearer()

router = APIRouter(prefix="/geofences", tags=["Geofences"])


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
) -> User:
    token = credentials.credentials
    try:
        payload = SecurityService.verify_token(token)
        user_id = payload.get("sub")
        if not user_id or payload.get("type") != "access":
            raise ValueError("Invalid token")
        user = await AuthService.get_user_by_id(db, user_id)
        if not user or not user.is_active:
            raise ValueError("User not found or inactive")
        return user
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )


@router.get("", response_model=List[GeofenceResponse])
async def list_geofences(
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """List geofences owned by the current user."""
    cursor = db.geofences.find({"owner_id": current_user.id}).sort("created_at", -1)
    geofences = [Geofence.from_mongo(g) async for g in cursor]
    return [
        GeofenceResponse(
            id=g.id,
            name=g.name,
            description=g.description,
            center_lat=g.center_lat,
            center_lng=g.center_lng,
            radius_meters=g.radius_meters,
            alert_on_enter=g.alert_on_enter,
            alert_on_exit=g.alert_on_exit,
            is_active=g.is_active,
            created_at=g.created_at,
        )
        for g in geofences
    ]


@router.post("", response_model=GeofenceResponse, status_code=status.HTTP_201_CREATED)
async def create_geofence(
    request: GeofenceCreateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """Create a new geofence."""
    geofence = Geofence(
        owner_id=current_user.id,
        name=request.name,
        description=request.description,
        center_lat=request.center_lat,
        center_lng=request.center_lng,
        radius_meters=request.radius_meters,
        alert_on_enter=request.alert_on_enter,
        alert_on_exit=request.alert_on_exit,
    )
    await db.geofences.insert_one(geofence.to_mongo())

    return GeofenceResponse(
        id=geofence.id,
        name=geofence.name,
        description=geofence.description,
        center_lat=geofence.center_lat,
        center_lng=geofence.center_lng,
        radius_meters=geofence.radius_meters,
        alert_on_enter=geofence.alert_on_enter,
        alert_on_exit=geofence.alert_on_exit,
        is_active=geofence.is_active,
        created_at=geofence.created_at,
    )


@router.delete("/{geofence_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_geofence(
    geofence_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """Delete a geofence."""
    raw = await db.geofences.find_one({"_id": geofence_id})
    if not raw:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Geofence not found")
    if raw.get("owner_id") != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your geofence")
    await db.geofences.delete_one({"_id": geofence_id})
    return None
