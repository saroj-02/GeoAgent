"""
Satellite imagery API routes (stub — extend with provider integrations).
"""

import logging
from fastapi import APIRouter, HTTPException, status

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/satellite", tags=["Satellite"])


@router.get("/scenes")
async def list_scenes():
    """List available satellite scenes."""
    return {"scenes": [], "message": "Satellite integration coming soon"}


@router.get("/scenes/{scene_id}")
async def get_scene(scene_id: str):
    """Get a specific satellite scene."""
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"Scene {scene_id} not found",
    )
