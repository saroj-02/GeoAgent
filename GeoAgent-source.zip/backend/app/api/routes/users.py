"""
Users API routes.
"""

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.database import get_async_db
from app.core.security import SecurityService
from app.services.auth import AuthService
from app.models import User
from app.schemas import UserResponse, UserUpdateRequest

logger = logging.getLogger(__name__)

security = HTTPBearer()

router = APIRouter(prefix="/users", tags=["Users"])


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
) -> User:
    """
    Get the currently authenticated user from the JWT access token.
    """

    token = credentials.credentials

    try:
        payload = SecurityService.verify_token(token)

        user_id = payload.get("sub")

        if not user_id:
            raise ValueError("Token does not contain a user ID")

        if payload.get("type") != "access":
            raise ValueError("Token is not an access token")

        user = await AuthService.get_user_by_id(db, user_id)

        if not user:
            raise ValueError("User not found")

        if not user.is_active:
            raise ValueError("User account is inactive")

        return user

    except Exception as e:
        logger.warning("Authentication failed: %s", e)

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from e


@router.get("/me", response_model=UserResponse)
async def get_me(
    current_user: User = Depends(get_current_user),
):
    """
    Get the currently authenticated user's profile.
    """

    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        username=current_user.username,
        full_name=current_user.full_name,
        email_verified=current_user.email_verified,
        is_active=current_user.is_active,
        created_at=current_user.created_at,
    )


@router.patch("/me", response_model=UserResponse)
async def update_me(
    request: UserUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """
    Update the currently authenticated user's profile.
    """

    updates = {}

    if request.full_name is not None:
        updates["full_name"] = request.full_name

    if request.phone is not None:
        updates["phone"] = request.phone

    if request.location_history_enabled is not None:
        updates["location_history_enabled"] = request.location_history_enabled

    if request.location_retention_days is not None:
        updates["location_retention_days"] = request.location_retention_days

    if updates:
        updates["updated_at"] = datetime.now(timezone.utc)

        result = await db.users.update_one(
            {"_id": current_user.id},
            {"$set": updates},
        )

        if result.matched_count == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        # Keep the in-memory user object synchronized.
        for key, value in updates.items():
            setattr(current_user, key, value)

    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        username=current_user.username,
        full_name=current_user.full_name,
        email_verified=current_user.email_verified,
        is_active=current_user.is_active,
        created_at=current_user.created_at,
    )