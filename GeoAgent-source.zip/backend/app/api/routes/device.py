"""
Device management API routes.
"""

import logging
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.database import get_async_db
from app.core.security import SecurityService
from app.services.auth import AuthService
from app.services.device import DeviceService
from app.models import User
from app.schemas import (
    DeviceCreateRequest,
    DeviceResponse,
    DeviceUpdateRequest,
)

logger = logging.getLogger(__name__)
security = HTTPBearer()

router = APIRouter(prefix="/devices", tags=["Devices"])


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
) -> User:
    """Get current user from Bearer token."""
    token = credentials.credentials
    try:
        payload = SecurityService.verify_token(token)
        user_id = payload.get("sub")

        if not user_id or payload.get("type") != "access":
            raise ValueError("Invalid token")

        user = await AuthService.get_user_by_id(db, user_id)
        if not user or not user.is_active:
            raise ValueError("User not found or inactive")

        return user
    except Exception as e:
        logger.warning(f"Authentication failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )


def _device_response(device) -> DeviceResponse:
    return DeviceResponse(
        id=device.id,
        name=device.name,
        device_type=device.device_type,
        unique_identifier=device.unique_identifier,
        is_active=device.is_active,
        last_seen=device.last_seen,
        created_at=device.created_at,
    )


@router.post("", response_model=DeviceResponse, status_code=status.HTTP_201_CREATED)
async def create_device(
    request: DeviceCreateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """Create a new device."""
    try:
        device = await DeviceService.create_device(
            db=db,
            user_id=current_user.id,
            name=request.name,
            device_type=request.device_type,
            unique_identifier=request.unique_identifier,
        )

        logger.info(f"Device created by user {current_user.email}: {device.id}")

        return _device_response(device)

    except ValueError as e:
        logger.warning(f"Device creation failed: {e}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        logger.error(f"Device creation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create device",
        )


@router.get("", response_model=List[DeviceResponse])
async def list_devices(
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """List all devices for the current user."""
    try:
        devices = await DeviceService.get_user_devices(db, current_user.id)
        return [_device_response(d) for d in devices]
    except Exception as e:
        logger.error(f"Error listing devices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list devices",
        )


@router.get("/{device_id}", response_model=DeviceResponse)
async def get_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """Get device details."""
    try:
        device = await DeviceService.get_device(db, device_id)

        if not device:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Device not found")

        if device.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have access to this device",
            )

        return _device_response(device)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting device: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get device",
        )


@router.patch("/{device_id}", response_model=DeviceResponse)
async def update_device(
    device_id: str,
    request: DeviceUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """Update device details."""
    try:
        device = await DeviceService.get_device(db, device_id)

        if not device:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Device not found")

        if device.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to update this device",
            )

        updated_device = await DeviceService.update_device(
            db, device_id, name=request.name, is_active=request.is_active
        )

        logger.info(f"Device updated: {device_id}")

        return _device_response(updated_device)

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        logger.error(f"Device update error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update device",
        )


@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """Delete a device and all associated location data."""
    try:
        device = await DeviceService.get_device(db, device_id)

        if not device:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Device not found")

        if device.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to delete this device",
            )

        await DeviceService.delete_device(db, device_id)

        logger.info(f"Device deleted: {device_id}")

        return None

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        logger.error(f"Device deletion error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete device",
        )
