"""
Geospatial analysis API routes (stub — extend with analysis workflows).
"""

import logging
from fastapi import APIRouter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/analysis", tags=["Analysis"])


@router.get("/status")
async def analysis_status():
    """Get analysis service status."""
    return {"status": "operational", "message": "Analysis service coming soon"}


@router.get("/results")
async def list_results():
    """List analysis results."""
    return {"results": [], "count": 0}
