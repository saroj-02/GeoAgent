"""
Authentication API routes.
"""

import logging
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.database import get_async_db
from app.core.config import get_settings
from app.core.security import SecurityService
from app.services.auth import AuthService
from app.schemas import (
    UserRegisterRequest,
    UserLoginRequest,
    TokenResponse,
    RefreshTokenRequest,
    UserResponse,
)

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(
    request: UserRegisterRequest,
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """
    Register a new user.

    - **email**: Valid email address (must be unique)
    - **username**: Unique username (3-100 characters)
    - **password**: Strong password (min 8 chars, uppercase, digit, special char)
    - **full_name**: Optional full name
    """
    try:
        user = await AuthService.register_user(
            db=db,
            email=request.email,
            username=request.username,
            password=request.password,
            full_name=request.full_name,
        )

        logger.info(f"User registered successfully: {request.email}")

        return UserResponse(
            id=user.id,
            email=user.email,
            username=user.username,
            full_name=user.full_name,
            email_verified=user.email_verified,
            is_active=user.is_active,
            created_at=user.created_at,
        )

    except ValueError as e:
        logger.warning(f"Registration failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Registration error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Registration failed",
        )


@router.post("/login", response_model=TokenResponse)
async def login(
    request: UserLoginRequest,
    db: AsyncIOMotorDatabase = Depends(get_async_db),
):
    """
    Login with email and password.

    Returns access and refresh tokens for authenticated requests.
    """
    try:
        user = await AuthService.login_user(
            db=db,
            email=request.email,
            password=request.password,
        )

        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = SecurityService.create_access_token(
            data={"sub": str(user.id)},
            expires_delta=access_token_expires,
        )
        refresh_token = SecurityService.create_refresh_token(
            data={"sub": str(user.id)},
        )

        logger.info(f"User logged in: {request.email}")

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    except ValueError as e:
        logger.warning(f"Login failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Login failed",
        )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    request: RefreshTokenRequest,
):
    """Refresh access token using refresh token."""
    try:
        payload = SecurityService.verify_token(request.refresh_token)

        if payload.get("type") != "refresh":
            raise ValueError("Invalid token type")

        user_id = payload.get("sub")

        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = SecurityService.create_access_token(
            data={"sub": user_id},
            expires_delta=access_token_expires,
        )
        new_refresh_token = SecurityService.create_refresh_token(
            data={"sub": user_id},
        )

        logger.info(f"Token refreshed for user: {user_id}")

        return TokenResponse(
            access_token=access_token,
            refresh_token=new_refresh_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    except ValueError as e:
        logger.warning(f"Token refresh failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )
    except Exception as e:
        logger.error(f"Token refresh error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Token refresh failed",
        )
