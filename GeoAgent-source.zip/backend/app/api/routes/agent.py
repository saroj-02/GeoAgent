"""
AI Agent API routes (stub — extend with LLM integrations).
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase
from pydantic import BaseModel

from app.core.database import get_async_db
from app.core.security import SecurityService
from app.services.auth import AuthService
from app.models import User

logger = logging.getLogger(__name__)
security = HTTPBearer()

router = APIRouter(prefix="/agent", tags=["AI Agent"])


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: AsyncIOMotorDatabase = Depends(get_async_db),
) -> User:
    token = credentials.credentials
    try:
        payload = SecurityService.verify_token(token)
        user_id = payload.get("sub")
        if not user_id or payload.get("type") != "access":
            raise ValueError("Invalid token")
        user = await AuthService.get_user_by_id(db, user_id)
        if not user or not user.is_active:
            raise ValueError("User not found or inactive")
        return user
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )


class AgentQueryRequest(BaseModel):
    query: str
    context: dict = {}


@router.get("/status")
async def agent_status():
    """Get AI agent service status."""
    return {"status": "operational", "model": "gpt-4", "message": "AI Agent ready"}


@router.post("/query")
async def agent_query(
    request: AgentQueryRequest,
    current_user: User = Depends(get_current_user),
):
    """Send a query to the AI agent."""
    # Placeholder — integrate your LLM here
    return {
        "response": f"AI Agent received: '{request.query}'. LLM integration coming soon.",
        "user_id": current_user.id,
    }
