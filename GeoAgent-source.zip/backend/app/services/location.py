"""
Location tracking service using Motor async MongoDB driver.
"""

import logging
import math
from datetime import datetime, timedelta
from typing import List, Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.config import get_settings
from app.models import LocationPoint
from app.services.permission import PermissionService

logger = logging.getLogger(__name__)
settings = get_settings()


class LocationService:
    """Location tracking and retrieval service."""

    @staticmethod
    def validate_location(
        latitude: float,
        longitude: float,
        previous_point: Optional[LocationPoint] = None,
        accuracy: Optional[float] = None,
    ) -> tuple:
        """
        Validate a location point.

        Returns:
            Tuple of (is_valid, validation_notes)
        """
        if not (-90 <= latitude <= 90):
            return False, "Invalid latitude range"

        if not (-180 <= longitude <= 180):
            return False, "Invalid longitude range"

        if accuracy is not None and accuracy < 0:
            return False, "Accuracy cannot be negative"

        if previous_point:
            distance = LocationService._calculate_distance(
                previous_point.latitude,
                previous_point.longitude,
                latitude,
                longitude,
            )
            if distance > settings.MAX_GPS_JUMP_METERS:
                return False, f"Impossible location jump: {distance:.0f}m"

        return True, None

    @staticmethod
    def _calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two points in meters (Haversine)."""
        R = 6371000
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lon = math.radians(lon2 - lon1)
        a = (
            math.sin(delta_lat / 2) ** 2
            + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
        )
        return R * 2 * math.asin(math.sqrt(a))

    @staticmethod
    async def create_location(
        db: AsyncIOMotorDatabase,
        device_id: str,
        latitude: float,
        longitude: float,
        accuracy: Optional[float] = None,
        altitude: Optional[float] = None,
        speed: Optional[float] = None,
        heading: Optional[float] = None,
        timestamp: datetime = None,
        source: str = "gps",
    ) -> LocationPoint:
        """Create a location point."""
        if timestamp is None:
            timestamp = datetime.utcnow()

        # Verify device exists
        if not await db.devices.find_one({"_id": device_id}):
            raise ValueError(f"Device {device_id} not found")

        # Get previous location for jump validation
        raw_prev = await db.locations.find_one(
            {"device_id": device_id, "is_valid": True},
            sort=[("timestamp", -1)],
        )
        previous_point = LocationPoint.from_mongo(raw_prev) if raw_prev else None

        # Validate
        is_valid, notes = LocationService.validate_location(
            latitude, longitude, previous_point, accuracy
        )

        location = LocationPoint(
            device_id=device_id,
            latitude=latitude,
            longitude=longitude,
            accuracy=accuracy,
            altitude=altitude,
            speed=speed,
            heading=heading,
            timestamp=timestamp,
            source=source,
            is_valid=is_valid,
            notes=notes,
        )

        await db.locations.insert_one(location.to_mongo())

        # Update device last_seen
        await db.devices.update_one(
            {"_id": device_id},
            {"$set": {"last_seen": datetime.utcnow()}}
        )

        logger.info(
            f"Location created: Device {device_id}, Valid: {is_valid}, Source: {source}"
        )

        return location

    @staticmethod
    async def get_current_location(
        db: AsyncIOMotorDatabase,
        device_id: str,
    ) -> Optional[LocationPoint]:
        """Get the most recent location for a device."""
        raw = await db.locations.find_one(
            {"device_id": device_id},
            sort=[("timestamp", -1)],
        )
        return LocationPoint.from_mongo(raw) if raw else None

    @staticmethod
    async def get_location_history(
        db: AsyncIOMotorDatabase,
        device_id: str,
        start_date: datetime = None,
        end_date: datetime = None,
        limit: int = 1000,
    ) -> List[LocationPoint]:
        """Get location history for a device within a date range."""
        if end_date is None:
            end_date = datetime.utcnow()
        if start_date is None:
            start_date = end_date - timedelta(days=settings.LOCATION_RETENTION_DAYS)

        cursor = db.locations.find(
            {
                "device_id": device_id,
                "timestamp": {"$gte": start_date, "$lte": end_date},
                "is_valid": True,
            }
        ).sort("timestamp", 1).limit(limit)

        return [LocationPoint.from_mongo(d) async for d in cursor]

    @staticmethod
    async def cleanup_old_locations(
        db: AsyncIOMotorDatabase,
        retention_days: int = None,
    ) -> int:
        """Delete locations older than retention period."""
        if retention_days is None:
            retention_days = settings.LOCATION_RETENTION_DAYS

        cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
        result = await db.locations.delete_many({"created_at": {"$lt": cutoff_date}})

        logger.info(f"Cleaned up {result.deleted_count} old location points")
        return result.deleted_count

    @staticmethod
    async def get_location_with_permission_check(
        db: AsyncIOMotorDatabase,
        device_id: str,
        requester_id: str,
    ) -> Optional[LocationPoint]:
        """Get current location with permission check."""
        has_permission = await PermissionService.check_permission(
            db, device_id, requester_id, permission_type="current"
        )
        if not has_permission:
            logger.warning(
                f"Unauthorized location access: User {requester_id} -> Device {device_id}"
            )
            return None
        return await LocationService.get_current_location(db, device_id)

    @staticmethod
    async def get_location_history_with_permission_check(
        db: AsyncIOMotorDatabase,
        device_id: str,
        requester_id: str,
        start_date: datetime = None,
        end_date: datetime = None,
        limit: int = 1000,
    ) -> Optional[List[LocationPoint]]:
        """Get location history with permission check."""
        has_permission = await PermissionService.check_permission(
            db, device_id, requester_id, permission_type="history"
        )
        if not has_permission:
            logger.warning(
                f"Unauthorized history access: User {requester_id} -> Device {device_id}"
            )
            return None
        return await LocationService.get_location_history(
            db, device_id, start_date, end_date, limit
        )
