"""
Device management service using Motor async MongoDB driver.
"""

import logging
from datetime import datetime
from typing import List, Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from app.models import Device

logger = logging.getLogger(__name__)


class DeviceService:
    """Device management service."""

    @staticmethod
    async def create_device(
        db: AsyncIOMotorDatabase,
        user_id: str,
        name: str,
        device_type: str,
        unique_identifier: str,
    ) -> Device:
        """
        Create a new device for a user.

        Raises:
            ValueError: If device already exists or user not found
        """
        # Check user exists
        if not await db.users.find_one({"_id": user_id}):
            raise ValueError(f"User {user_id} not found")

        # Check duplicate identifier
        if await db.devices.find_one({"unique_identifier": unique_identifier}):
            raise ValueError(f"Device with identifier {unique_identifier} already exists")

        device = Device(
            user_id=user_id,
            name=name,
            device_type=device_type,
            unique_identifier=unique_identifier,
        )

        await db.devices.insert_one(device.to_mongo())

        logger.info(f"Device created: {device.id} (owner: {user_id})")

        return device

    @staticmethod
    async def get_device(
        db: AsyncIOMotorDatabase,
        device_id: str,
    ) -> Optional[Device]:
        """Get device by ID."""
        raw = await db.devices.find_one({"_id": device_id})
        return Device.from_mongo(raw) if raw else None

    @staticmethod
    async def get_user_devices(
        db: AsyncIOMotorDatabase,
        user_id: str,
    ) -> List[Device]:
        """Get all devices for a user."""
        cursor = db.devices.find({"user_id": user_id}).sort("created_at", -1)
        return [Device.from_mongo(d) async for d in cursor]

    @staticmethod
    async def update_device(
        db: AsyncIOMotorDatabase,
        device_id: str,
        name: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> Device:
        """Update device details."""
        updates: dict = {"updated_at": datetime.utcnow()}

        if name is not None:
            updates["name"] = name

        if is_active is not None:
            updates["is_active"] = is_active

        result = await db.devices.find_one_and_update(
            {"_id": device_id},
            {"$set": updates},
            return_document=True,
        )

        if not result:
            raise ValueError(f"Device {device_id} not found")

        logger.info(f"Device updated: {device_id}")

        return Device.from_mongo(result)

    @staticmethod
    async def delete_device(
        db: AsyncIOMotorDatabase,
        device_id: str,
    ) -> None:
        """Delete a device and all associated data."""
        result = await db.devices.delete_one({"_id": device_id})

        if result.deleted_count == 0:
            raise ValueError(f"Device {device_id} not found")

        # Cascade: remove related locations and permissions
        await db.locations.delete_many({"device_id": device_id})
        await db.permissions.delete_many({"device_id": device_id})

        logger.info(f"Device deleted: {device_id}")

    @staticmethod
    async def get_device_by_identifier(
        db: AsyncIOMotorDatabase,
        unique_identifier: str,
    ) -> Optional[Device]:
        """Get device by unique identifier."""
        raw = await db.devices.find_one({"unique_identifier": unique_identifier})
        return Device.from_mongo(raw) if raw else None
