"""
Authentication service for GeoAgent.

Handles:
- User registration
- User login
- Email verification
- User lookup
- Password hashing
- Automatic password-hash migration

Uses Motor async MongoDB driver.
"""

import logging
import secrets
from datetime import datetime, timedelta
from typing import Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.config import get_settings
from app.core.security import SecurityService
from app.models import User


logger = logging.getLogger(__name__)
settings = get_settings()


class AuthService:
    """Authentication service for user operations."""

    # -----------------------------------------------------------------------
    # Registration
    # -----------------------------------------------------------------------

    @staticmethod
    async def register_user(
        db: AsyncIOMotorDatabase,
        email: str,
        username: str,
        password: str,
        full_name: Optional[str] = None,
    ) -> User:
        """
        Register a new user.

        Passwords are hashed using Argon2id.

        There is intentionally NO bcrypt 72-byte restriction because
        Argon2id is now used for new passwords.

        Raises:
            ValueError:
                If password validation fails, email exists, or username
                already exists.
        """

        # ---------------------------------------------------------------
        # Validate password requirements.
        #
        # This does NOT impose an artificial maximum password length.
        # ---------------------------------------------------------------
        AuthService._validate_password(password)

        # ---------------------------------------------------------------
        # Check email uniqueness.
        # ---------------------------------------------------------------
        existing_email = await db.users.find_one(
            {"email": email}
        )

        if existing_email:
            raise ValueError(
                f"Email {email} already registered"
            )

        # ---------------------------------------------------------------
        # Check username uniqueness.
        # ---------------------------------------------------------------
        existing_username = await db.users.find_one(
            {"username": username}
        )

        if existing_username:
            raise ValueError(
                f"Username {username} already taken"
            )

        # ---------------------------------------------------------------
        # Create email verification token.
        # ---------------------------------------------------------------
        verification_token = secrets.token_urlsafe(32)

        verification_expires = datetime.utcnow() + timedelta(
            hours=settings.EMAIL_VERIFICATION_EXPIRY_HOURS
        )

        # ---------------------------------------------------------------
        # Hash password using Argon2id.
        # ---------------------------------------------------------------
        password_hash = SecurityService.hash_password(
            password
        )

        # ---------------------------------------------------------------
        # Create user.
        # ---------------------------------------------------------------
        new_user = User(
            email=email,
            username=username,
            password_hash=password_hash,
            full_name=full_name,
            email_verification_token=verification_token,
            email_verification_expires=verification_expires,
        )

        # ---------------------------------------------------------------
        # Store user in MongoDB.
        # ---------------------------------------------------------------
        await db.users.insert_one(
            new_user.to_mongo()
        )

        logger.info(
            "User registered: %s (ID: %s)",
            email,
            new_user.id,
        )

        return new_user

    # -----------------------------------------------------------------------
    # Login
    # -----------------------------------------------------------------------

    @staticmethod
    async def login_user(
        db: AsyncIOMotorDatabase,
        email: str,
        password: str,
    ) -> User:
        """
        Login user and verify credentials.

        Existing bcrypt hashes remain supported.

        If an existing bcrypt password is successfully verified,
        the password hash is automatically upgraded to Argon2id.

        Raises:
            ValueError:
                If credentials are invalid or account is inactive.
        """

        # ---------------------------------------------------------------
        # Find user.
        # ---------------------------------------------------------------
        raw = await db.users.find_one(
            {"email": email}
        )

        if not raw:
            logger.warning(
                "Login attempt for non-existent user: %s",
                email,
            )

            raise ValueError(
                "Invalid email or password"
            )

        # ---------------------------------------------------------------
        # Convert MongoDB document to User model.
        # ---------------------------------------------------------------
        user = User.from_mongo(raw)

        # ---------------------------------------------------------------
        # Verify password.
        # ---------------------------------------------------------------
        password_valid = SecurityService.verify_password(
            password,
            user.password_hash,
        )

        if not password_valid:
            logger.warning(
                "Invalid password for user: %s",
                email,
            )

            raise ValueError(
                "Invalid email or password"
            )

        # ---------------------------------------------------------------
        # Automatically upgrade old password hashes.
        #
        # If the user's password was stored using bcrypt, it will be
        # replaced with an Argon2id hash after successful login.
        # ---------------------------------------------------------------
        if SecurityService.needs_password_rehash(
            user.password_hash
        ):
            try:
                new_password_hash = SecurityService.hash_password(
                    password
                )

                await db.users.update_one(
                    {"_id": user.id},
                    {
                        "$set": {
                            "password_hash": new_password_hash
                        }
                    },
                )

                user.password_hash = new_password_hash

                logger.info(
                    "Password hash upgraded to Argon2 for user: %s",
                    email,
                )

            except Exception as e:
                # Do not fail login just because hash migration failed.
                logger.error(
                    "Password hash upgrade failed for %s: %s",
                    email,
                    e,
                )

        # ---------------------------------------------------------------
        # Check account status.
        # ---------------------------------------------------------------
        if not user.is_active:
            logger.warning(
                "Login attempt for inactive user: %s",
                email,
            )

            raise ValueError(
                "Account is inactive"
            )

        # ---------------------------------------------------------------
        # Update last login.
        # ---------------------------------------------------------------
        last_login = datetime.utcnow()

        await db.users.update_one(
            {"_id": user.id},
            {
                "$set": {
                    "last_login": last_login
                }
            },
        )

        user.last_login = last_login

        logger.info(
            "User logged in: %s",
            email,
        )

        return user

    # -----------------------------------------------------------------------
    # Email verification
    # -----------------------------------------------------------------------

    @staticmethod
    async def verify_email(
        db: AsyncIOMotorDatabase,
        user_id: str,
        token: str,
    ) -> User:
        """Verify user email with token."""

        raw = await db.users.find_one(
            {"_id": user_id}
        )

        if not raw:
            raise ValueError(
                "User not found"
            )

        user = User.from_mongo(raw)

        if user.email_verification_token != token:
            raise ValueError(
                "Invalid verification token"
            )

        if (
            user.email_verification_expires
            and user.email_verification_expires < datetime.utcnow()
        ):
            raise ValueError(
                "Verification token expired"
            )

        await db.users.update_one(
            {"_id": user_id},
            {
                "$set": {
                    "email_verified": True,
                    "email_verification_token": None,
                    "email_verification_expires": None,
                }
            },
        )

        user.email_verified = True

        logger.info(
            "Email verified for user: %s",
            user.email,
        )

        return user

    # -----------------------------------------------------------------------
    # User lookup
    # -----------------------------------------------------------------------

    @staticmethod
    async def get_user_by_id(
        db: AsyncIOMotorDatabase,
        user_id: str,
    ) -> Optional[User]:
        """Get user by ID."""

        raw = await db.users.find_one(
            {"_id": user_id}
        )

        return (
            User.from_mongo(raw)
            if raw
            else None
        )

    @staticmethod
    async def get_user_by_email(
        db: AsyncIOMotorDatabase,
        email: str,
    ) -> Optional[User]:
        """Get user by email."""

        raw = await db.users.find_one(
            {"email": email}
        )

        return (
            User.from_mongo(raw)
            if raw
            else None
        )

    # -----------------------------------------------------------------------
    # Password validation
    # -----------------------------------------------------------------------

    @staticmethod
    def _validate_password(password: str) -> None:
        """
        Validate password security requirements.

        IMPORTANT:
        There is intentionally NO maximum password length here.

        The password can be longer than 72 bytes because GeoAgent now
        uses Argon2id instead of bcrypt for new password hashes.
        """

        # ---------------------------------------------------------------
        # Basic validation.
        # ---------------------------------------------------------------
        if not isinstance(password, str):
            raise ValueError(
                "Password must be a string"
            )

        if not password:
            raise ValueError(
                "Password cannot be empty"
            )

        # ---------------------------------------------------------------
        # Minimum length.
        # ---------------------------------------------------------------
        if len(password) < settings.PASSWORD_MIN_LENGTH:
            raise ValueError(
                f"Password must be at least "
                f"{settings.PASSWORD_MIN_LENGTH} characters"
            )

        # ---------------------------------------------------------------
        # Special character requirement.
        # ---------------------------------------------------------------
        if settings.PASSWORD_REQUIRE_SPECIAL:
            special_characters = (
                "!@#$%^&*()-_=+[]{}|;:,.<>?"
            )

            if not any(
                character in special_characters
                for character in password
            ):
                raise ValueError(
                    "Password must contain at least "
                    "one special character"
                )

        # ---------------------------------------------------------------
        # Uppercase requirement.
        # ---------------------------------------------------------------
        if hasattr(settings, "PASSWORD_REQUIRE_UPPERCASE"):
            if settings.PASSWORD_REQUIRE_UPPERCASE:
                if not any(
                    character.isupper()
                    for character in password
                ):
                    raise ValueError(
                        "Password must contain at least "
                        "one uppercase letter"
                    )

        # ---------------------------------------------------------------
        # Lowercase requirement.
        # ---------------------------------------------------------------
        if hasattr(settings, "PASSWORD_REQUIRE_LOWERCASE"):
            if settings.PASSWORD_REQUIRE_LOWERCASE:
                if not any(
                    character.islower()
                    for character in password
                ):
                    raise ValueError(
                        "Password must contain at least "
                        "one lowercase letter"
                    )

        # ---------------------------------------------------------------
        # Digit requirement.
        # ---------------------------------------------------------------
        if hasattr(settings, "PASSWORD_REQUIRE_DIGIT"):
            if settings.PASSWORD_REQUIRE_DIGIT:
                if not any(
                    character.isdigit()
                    for character in password
                ):
                    raise ValueError(
                        "Password must contain at least one digit"
                    )