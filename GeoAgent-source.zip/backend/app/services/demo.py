"""
Demo mode simulator for location tracking.
Generates simulated location updates along predefined routes.
"""

import logging
import asyncio
import random
from datetime import datetime
from uuid import UUID
from typing import Optional, List

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.services.location import LocationService
from app.services.device import DeviceService

logger = logging.getLogger(__name__)
settings = get_settings()


class DemoModeSimulator:
    """Simulates realistic device location updates for demo purposes."""
    
    def __init__(self):
        self.current_point_index = 0
        self.simulation_running = False
        self.update_interval = settings.LOCATION_UPDATE_INTERVAL_SECONDS
        self.route_points = settings.DEMO_ROUTE_POINTS
        
    @staticmethod
    async def initialize_demo_device(
        session: AsyncSession,
        user_id: UUID,
    ) -> Optional[str]:
        """
        Initialize demo device for a user.
        
        Args:
            session: Database session
            user_id: User ID
            
        Returns:
            Device ID if created, None if already exists
        """
        if not settings.DEMO_MODE_ENABLED:
            logger.warning("Demo mode is disabled")
            return None
        
        try:
            # Check if demo device already exists for this user
            from sqlalchemy.future import select
            from app.models import Device
            
            result = await session.execute(
                select(Device).where(
                    Device.user_id == user_id,
                    Device.unique_identifier == settings.DEMO_DEVICE_ID,
                )
            )
            
            existing_device = result.scalar_one_or_none()
            if existing_device:
                logger.info(f"Demo device already exists: {existing_device.id}")
                return str(existing_device.id)
            
            # Create demo device
            device = await DeviceService.create_device(
                session=session,
                user_id=user_id,
                name="Demo Device (Simulated)",
                device_type="web",
                unique_identifier=settings.DEMO_DEVICE_ID,
            )
            
            await session.flush()
            
            logger.info(f"Demo device created: {device.id}")
            
            return str(device.id)
            
        except Exception as e:
            logger.error(f"Failed to initialize demo device: {e}")
            return None
    
    @staticmethod
    def add_location_noise(
        latitude: float,
        longitude: float,
        noise_magnitude: float = 0.0001,
    ) -> tuple[float, float]:
        """
        Add small random noise to coordinates for realistic simulation.
        
        Args:
            latitude: Base latitude
            longitude: Base longitude
            noise_magnitude: Random noise magnitude
            
        Returns:
            Tuple of (noisy_latitude, noisy_longitude)
        """
        noisy_lat = latitude + random.uniform(-noise_magnitude, noise_magnitude)
        noisy_lng = longitude + random.uniform(-noise_magnitude, noise_magnitude)
        
        return noisy_lat, noisy_lng
    
    @staticmethod
    async def submit_demo_location(
        session: AsyncSession,
        device_id: UUID,
        latitude: float,
        longitude: float,
        add_noise: bool = True,
    ) -> bool:
        """
        Submit a simulated location point.
        
        Args:
            session: Database session
            device_id: Device ID
            latitude: Latitude
            longitude: Longitude
            add_noise: Add realistic GPS noise
            
        Returns:
            True if submitted successfully
        """
        try:
            # Add noise for realism
            if add_noise:
                latitude, longitude = DemoModeSimulator.add_location_noise(
                    latitude,
                    longitude,
                    noise_magnitude=0.00005,  # ~5 meters
                )
            
            # Simulate realistic accuracy (5-15 meters)
            accuracy = random.uniform(5, 15)
            
            # Simulate speed (0-20 m/s = 0-72 km/h)
            speed = random.uniform(0, 20)
            
            location = await LocationService.create_location(
                session=session,
                device_id=device_id,
                latitude=latitude,
                longitude=longitude,
                accuracy=accuracy,
                speed=speed,
                heading=random.uniform(0, 360),
                timestamp=datetime.utcnow(),
                source="simulated",
            )
            
            logger.debug(
                f"Demo location submitted: Device {device_id}, "
                f"Lat: {latitude:.6f}, Lng: {longitude:.6f}, "
                f"Accuracy: {accuracy:.1f}m"
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to submit demo location: {e}")
            return False
    
    @staticmethod
    async def simulate_route_movement(
        session: AsyncSession,
        device_id: UUID,
        route_points: List[dict],
        iterations: int = None,
        delay_between_points: int = None,
    ) -> None:
        """
        Simulate device movement along a route.
        
        Args:
            session: Database session
            device_id: Device ID
            route_points: List of route points with lat/lng
            iterations: Number of times to repeat route (None = infinite)
            delay_between_points: Seconds between location updates
            
        Example:
            route = [
                {"lat": 20.4625, "lng": 85.8830},
                {"lat": 20.4627, "lng": 85.8833},
                {"lat": 20.4631, "lng": 85.8840},
            ]
            
            await DemoModeSimulator.simulate_route_movement(
                session, device_id, route, iterations=2
            )
        """
        if not route_points:
            logger.error("No route points provided")
            return
        
        if delay_between_points is None:
            delay_between_points = settings.LOCATION_UPDATE_INTERVAL_SECONDS
        
        iteration = 0
        while iterations is None or iteration < iterations:
            for point in route_points:
                try:
                    success = await DemoModeSimulator.submit_demo_location(
                        session=session,
                        device_id=device_id,
                        latitude=point["lat"],
                        longitude=point["lng"],
                        add_noise=True,
                    )
                    
                    if success:
                        await session.commit()
                    
                    # Delay before next update
                    await asyncio.sleep(delay_between_points)
                    
                except Exception as e:
                    logger.error(f"Error in route simulation: {e}")
                    await session.rollback()
                    await asyncio.sleep(delay_between_points)
            
            iteration += 1
            logger.info(f"Demo route iteration {iteration} completed")
    
    @staticmethod
    async def generate_demo_location_batch(
        session: AsyncSession,
        device_id: UUID,
        route_points: List[dict],
        batch_size: int = 10,
    ) -> int:
        """
        Generate a batch of location points along a route.
        Useful for creating historical data quickly.
        
        Args:
            session: Database session
            device_id: Device ID
            route_points: Route points
            batch_size: Number of points per route cycle
            
        Returns:
            Number of points created
        """
        created_count = 0
        
        try:
            for i in range(batch_size):
                point = route_points[i % len(route_points)]
                
                success = await DemoModeSimulator.submit_demo_location(
                    session=session,
                    device_id=device_id,
                    latitude=point["lat"],
                    longitude=point["lng"],
                    add_noise=True,
                )
                
                if success:
                    created_count += 1
            
            await session.commit()
            logger.info(f"Generated {created_count} demo location points")
            
            return created_count
            
        except Exception as e:
            logger.error(f"Error generating demo batch: {e}")
            await session.rollback()
            return 0
