"""
Satellite document models for MongoDB.
"""

from datetime import datetime
from typing import Optional
from uuid import uuid4
from pydantic import BaseModel, Field


class SatelliteScene(BaseModel):
    """Represents a satellite scene document in 'satellite_scenes' collection."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    provider: str   # e.g. "sentinel-2", "landsat-8"
    scene_id: str   # unique external scene identifier

    center_latitude: float
    center_longitude: float
    captured_at: datetime

    cloud_cover_pct: Optional[float] = None
    asset_url: Optional[str] = None

    created_at: datetime = Field(default_factory=datetime.utcnow)

    def to_mongo(self) -> dict:
        data = self.model_dump()
        data["_id"] = data.pop("id")
        return data

    @classmethod
    def from_mongo(cls, data: dict) -> "SatelliteScene":
        if data is None:
            return None
        d = dict(data)
        d["id"] = str(d.pop("_id", d.get("id", str(uuid4()))))
        return cls(**d)


class AnalysisResult(BaseModel):
    """Represents an analysis result document in 'analysis_results' collection."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    scene_id: str

    analysis_type: str   # e.g. "ndvi", "change_detection"
    summary: Optional[str] = None
    result_url: Optional[str] = None

    created_at: datetime = Field(default_factory=datetime.utcnow)

    def to_mongo(self) -> dict:
        data = self.model_dump()
        data["_id"] = data.pop("id")
        return data

    @classmethod
    def from_mongo(cls, data: dict) -> "AnalysisResult":
        if data is None:
            return None
        d = dict(data)
        d["id"] = str(d.pop("_id", d.get("id", str(uuid4()))))
        return cls(**d)