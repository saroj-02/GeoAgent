"""
Security utilities for GeoAgent.

Password hashing:
- Argon2id is used for all newly created passwords.
- Existing bcrypt hashes remain supported for backward compatibility.
- Successful bcrypt authentication is automatically upgraded to Argon2id.
"""

from datetime import datetime, timedelta, timezone
from typing import Optional
import logging

from fastapi import HTTPException, status
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import get_settings


logger = logging.getLogger(__name__)
settings = get_settings()


# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------
#
# Argon2 is the primary/default hashing algorithm.
#
# bcrypt is kept as a secondary scheme so users with passwords that were
# already stored using bcrypt can still log in.
#
# "deprecated=auto" means Passlib will consider bcrypt hashes outdated and
# can re-hash them using Argon2 when the password is successfully verified.
#
# Argon2 does NOT have bcrypt's 72-byte password limitation.
#
pwd_context = CryptContext(
    schemes=[
        "argon2",
        "bcrypt",
    ],
    deprecated="auto",
)


class SecurityService:
    """Handle all security-related operations."""

    # -----------------------------------------------------------------------
    # Password hashing
    # -----------------------------------------------------------------------

    @staticmethod
    def hash_password(password: str) -> str:
        """
        Hash a password using Argon2id.

        Argon2 is used for all new passwords, so there is no bcrypt
        72-byte password restriction.

        Args:
            password: Plain-text password.

        Returns:
            Secure Argon2 password hash.
        """

        if not isinstance(password, str):
            raise ValueError("Password must be a string")

        if not password:
            raise ValueError("Password cannot be empty")

        return pwd_context.hash(password)

    @staticmethod
    def verify_password(
        plain_password: str,
        hashed_password: str,
    ) -> bool:
        """
        Verify a plain-text password against a stored password hash.

        Supports both:
        - Argon2 hashes created by the current system.
        - Existing bcrypt hashes created by older versions.

        Returns:
            True if the password matches, otherwise False.
        """

        try:
            if not isinstance(plain_password, str):
                return False

            if not isinstance(hashed_password, str):
                return False

            if not plain_password:
                return False

            return pwd_context.verify(
                plain_password,
                hashed_password,
            )

        except Exception as e:
            logger.warning(
                "Password verification failed: %s",
                e,
            )
            return False

    @staticmethod
    def needs_password_rehash(hashed_password: str) -> bool:
        """
        Determine whether a stored password hash should be upgraded.

        Existing bcrypt hashes will return True because Argon2 is now the
        preferred hashing scheme.
        """

        try:
            return pwd_context.needs_update(hashed_password)

        except Exception as e:
            logger.warning(
                "Unable to determine password hash status: %s",
                e,
            )
            return False

    # -----------------------------------------------------------------------
    # JWT access token
    # -----------------------------------------------------------------------

    @staticmethod
    def create_access_token(
        data: dict,
        expires_delta: Optional[timedelta] = None,
    ) -> str:
        """Create a JWT access token."""

        to_encode = data.copy()

        if expires_delta:
            expire = datetime.now(timezone.utc) + expires_delta
        else:
            expire = datetime.now(timezone.utc) + timedelta(
                minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
            )

        to_encode.update(
            {
                "exp": expire,
                "type": "access",
            }
        )

        encoded_jwt = jwt.encode(
            to_encode,
            settings.JWT_SECRET,
            algorithm=settings.JWT_ALGORITHM,
        )

        return encoded_jwt

    # -----------------------------------------------------------------------
    # JWT refresh token
    # -----------------------------------------------------------------------

    @staticmethod
    def create_refresh_token(data: dict) -> str:
        """Create a JWT refresh token."""

        to_encode = data.copy()

        expire = datetime.now(timezone.utc) + timedelta(
            days=settings.REFRESH_TOKEN_EXPIRE_DAYS
        )

        to_encode.update(
            {
                "exp": expire,
                "type": "refresh",
            }
        )

        encoded_jwt = jwt.encode(
            to_encode,
            settings.JWT_SECRET,
            algorithm=settings.JWT_ALGORITHM,
        )

        return encoded_jwt

    # -----------------------------------------------------------------------
    # JWT verification
    # -----------------------------------------------------------------------

    @staticmethod
    def verify_token(token: str) -> dict:
        """
        Verify and decode a JWT token.

        Raises:
            HTTPException: If the token is invalid or expired.
        """

        try:
            payload = jwt.decode(
                token,
                settings.JWT_SECRET,
                algorithms=[settings.JWT_ALGORITHM],
            )

            return payload

        except JWTError as e:
            logger.error(
                "Token verification failed: %s",
                e,
            )

            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token",
                headers={
                    "WWW-Authenticate": "Bearer",
                },
            )